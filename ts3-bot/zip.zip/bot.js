const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });
const express = require('express');
const cors = require('cors');
const logger = require('./utils/logger');
const mongoose = require('mongoose');
const botRoutes = require('../src/routes/bot');
const TS3Credentials = require('../src/models/ts3Credentials');
const botController = require('../src/controllers/botController');

const app = express();
const BOT_API_PORT = process.env.BOT_API_PORT || 3002;

// CORS and middleware setup
app.use(cors({
  origin: 'http://localhost:3000',
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  credentials: true,
}));
app.use(express.json());
app.use('/bot', botRoutes);

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI, {
  serverSelectionTimeoutMS: 30000,
})
.then(() => logger.info('Connected to MongoDB'))
.catch(err => {
  logger.error('Failed to connect to MongoDB:', err.message);
  process.exit(1);
});

// Authentication middleware
const authenticate = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (apiKey && apiKey === process.env.BOT_API_KEY) {
    next();
  } else {
    res.status(401).json({ message: 'Unauthorized' });
  }
};

// API endpoints
app.get('/status', authenticate, botController.getStatus);
app.get('/bot/settings', authenticate, botController.updateSettings);
app.post('/bot/settings', authenticate, botController.updateSettings);
app.post('/command', authenticate, botController.sendCommand);

// Initialize TeamSpeak client
const initializeBot = async () => {
  try {
    const settings = await TS3Credentials.findById('ts3_credentials');
    if (!settings) throw new Error('TS3 credentials not found');
    
    logger.info('TS3 Settings:', {
      host: settings.host,
      port: settings.port,
      username: settings.username,
      nickname: settings.nickname,
      serverId: settings.serverId,
      channelId: settings.channelId,
    });

    await botController.initializeClient(settings);
    return true;
  } catch (error) {
    logger.error(`Failed to initialize TS3 client: ${error.message}`);
    return false;
  }
};

// Start server and initialize bot
app.listen(BOT_API_PORT, async () => {
  logger.info(`Bot API server is running on port ${BOT_API_PORT}`);
  await initializeBot();
});

// Graceful shutdown handler
const shutdown = async (signal) => {
  logger.info(`Received ${signal}. Starting graceful shutdown...`);
  try {
    if (botController.cleanupChannels) {
      await botController.cleanupChannels();
    }
    if (mongoose.connection.readyState === 1) {
      await mongoose.connection.close();
      logger.info('Closed MongoDB connection');
    }
    process.exit(0);
  } catch (error) {
    logger.error('Error during shutdown:', error);
    process.exit(1);
  }
};

// Shutdown signal handlers
['SIGINT', 'SIGTERM', 'SIGHUP'].forEach(signal => {
  process.on(signal, () => shutdown(signal));
});