const { TeamSpeak } = require('ts3-nodejs-library');
const TS3Credentials = require('../models/ts3Credentials');
const logger = require('../utils/logger');
require('dotenv').config();

let client;
let mainChannelId = null;

// Helper functions
const safeDisconnect = async () => {
  if (client && client.connected) {
    try {
      await client.disconnect();
    } catch (error) {
      logger.error(`Error during safe disconnect: ${error.message}`);
    } finally {
      client = null;
    }
  }
};

const cleanupChannels = async () => {
  if (!client || !client.connected) {
    logger.info('No active client connection, skipping cleanup');
    return;
  }

  logger.info('Starting channel cleanup...');
  
  try {
    const channels = await client.channelList();
    const botChannels = channels.filter(ch => ch.name.includes('Bert Bot'));
    
    for (const channel of botChannels) {
      try {
        await client.channelDelete(channel.cid);
        logger.info(`Deleted channel ${channel.cid}`);
        await new Promise(resolve => setTimeout(resolve, 500));
      } catch (error) {
        logger.warn(`Failed to delete channel ${channel.cid}: ${error.message}`);
      }
    }
  } catch (error) {
    logger.error('Error during cleanup:', error);
  } finally {
    mainChannelId = null;
  }
};

// Core TeamSpeak functionality
const initializeClient = async (settings) => {
  await safeDisconnect();
  
  try {
    // Connection setup
    logger.info('Connecting to TS3 server...', {
      host: settings.host,
      queryport: settings.port,
      username: settings.username,
      nickname: settings.nickname,
    });

    client = await TeamSpeak.connect({
      host: settings.host,
      queryport: settings.port,
      username: settings.username,
      password: settings.password,
      nickname: settings.nickname,
      serverport: 9987,
      serverid: settings.serverId,
    });

    logger.info('Connected to TS3 server successfully.');

    // Channel setup
    await cleanupChannels();
    await createStatusChannel();
    await setupEventHandlers();

  } catch (error) {
    logger.error('Error in initialization:', error);
    await safeDisconnect();
    throw error;
  }
};

// Channel management
const createStatusChannel = async () => {
  try {
    const mainChannel = await client.channelCreate("━━ Bert the Bot [Online] ━━", {
      type: 0,
      maxclients: -1,
      codec: 4,
      codecQuality: 10
    });

    await client.channelEdit(mainChannel.cid, {
      channel_order: 0,
      channel_topic: "Bot Status: Online",
      channel_description: "[center][b]Bot Status[/b]\n[color=green]✓ Connected[/color]\n\nType !help for commands[/center]"
    });

    mainChannelId = mainChannel.cid;
    logger.info(`Created status channel with ID ${mainChannelId}`);
  } catch (error) {
    logger.error(`Error creating status channel: ${error.message}`);
  }
};

// Event handlers
const setupEventHandlers = async () => {
  try {
    await client.registerEvent("textprivate");
    
    client.on("textmessage", handleTextMessage);
    client.on("close", handleDisconnect);
    client.on("error", handleError);
    
    setupShutdownHandlers();
  } catch (error) {
    logger.error(`Error setting up event handlers: ${error.message}`);
  }
};

// Command handlers
const handleCommand = async (command, invoker) => {
  const commands = {
    ping: () => client.sendTextMessage(invoker.clid, 1, "Pong!"),
    help: () => client.sendTextMessage(invoker.clid, 1, "Available commands: !ping, !help"),
  };

  const handler = commands[command];
  if (handler) {
    await handler();
  } else {
    await client.sendTextMessage(invoker.clid, 1, `Unknown command: ${command}`);
  }
};

// API endpoint handlers
const getStatus = async (req, res) => {
  try {
    const status = client && client.connected ? 'online' : 'offline';
    res.json({ status });
  } catch (error) {
    logger.error(`Error getting status: ${error.message}`);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const updateSettings = async (req, res) => {
  try {
    const settings = req.body;
    await initializeClient(settings);
    res.json({ message: 'Settings updated successfully' });
  } catch (error) {
    logger.error(`Error updating settings: ${error.message}`);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

// Export only what's needed
module.exports = {
  initializeClient,
  getStatus,
  updateSettings,
  cleanupChannels,
};
