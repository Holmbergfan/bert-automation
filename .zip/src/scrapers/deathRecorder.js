// src/scrapers/deathRecorder.js

const axios = require('axios');
const cheerio = require('cheerio');
const Death = require('../models/Death');
const config = require('../config/config'); // Ensure this has baseUrl or relevant configs
const logger = require('../utils/logger');

const scrapeDeathRecorder = async () => {
  try {
    const response = await axios.get(`${config.baseUrl}/?subtopic=latestdeaths`);
    const html = response.data;
    const $ = cheerio.load(html);

    // Selector for the deaths table
    const deathsTable = $('div#ContentColumn table.TableContent.InnerBorder');

    if (!deathsTable.length) {
      logger.error('No deaths table found on the page.');
      return;
    }

    const newDeaths = [];

    // Iterate over each table row excluding the header
    deathsTable.find('tr').each((index, element) => {
      if (index === 0) return; // Skip header row if present

      const columns = $(element).find('td');

      if (columns.length < 2) return; // Ensure there are enough columns

      const timestampStr = $(columns[0]).text().trim(); // e.g., "28.10.2024, 18:58:10"
      const deathDescription = $(columns[1]).html(); // HTML content for the death description

      // Parse the timestamp
      const timestamp = parseTimestamp(timestampStr);
      if (!timestamp) {
        logger.warn(`Invalid timestamp format: ${timestampStr}`);
        return;
      }

      // Parse the death description
      const { victim, killer, victimLevel, killerLevel, reason, isTeammateKill } = parseDeathDescription(deathDescription);

      if (!victim || !killer || !victimLevel) {
        logger.warn(`Incomplete death data: Victim - ${victim}, Killer - ${killer}`);
        return;
      }

      // Check for duplicate deaths (optional: based on timestamp and victim)
      // Adjust the uniqueness criteria as needed
      newDeaths.push({
        victim,
        killer,
        victimLevel,
        killerLevel,
        timestamp,
        reason,
        isTeammateKill,
      });
    });

    // Filter out already recorded deaths
    const deathsToInsert = [];

    for (const death of newDeaths) {
      const exists = await Death.findOne({
        victim: death.victim,
        killer: death.killer,
        timestamp: death.timestamp,
      });

      if (!exists) {
        deathsToInsert.push(death);
      }
    }

    if (deathsToInsert.length > 0) {
      await Death.insertMany(deathsToInsert);
      logger.info(`Recorded ${deathsToInsert.length} new deaths.`);
    } else {
      logger.info('No new deaths to record.');
    }

    logger.info('Death Recorder scraper executed successfully.');
  } catch (error) {
    logger.error(`Error in Death Recorder scraper: ${error.message}`);
  }
};

// Helper function to parse timestamp string to Date object
const parseTimestamp = (timestampStr) => {
  // Expected format: "28.10.2024, 18:58:10"
  const [datePart, timePart] = timestampStr.split(',');
  if (!datePart || !timePart) return null;

  const [day, month, year] = datePart.trim().split('.');
  const [hours, minutes, seconds] = timePart.trim().split(':');

  if (!day || !month || !year || !hours || !minutes || !seconds) return null;

  const date = new Date(`${year}-${month}-${day}T${hours}:${minutes}:${seconds}Z`);
  if (isNaN(date.getTime())) {
    logger.warn(`Invalid Date object created from timestamp: ${timestampStr}`);
    return null;
  }

  return date;
};

// Helper function to parse death description HTML
const parseDeathDescription = (descriptionHtml) => {
  const $ = cheerio.load(descriptionHtml);
  const victim = $('b a').first().text().trim();
  const killerElement = $('b a').last();
  const killer = killerElement.length > 0 ? killerElement.text().trim() : extractKillerFromText($(descriptionHtml).text());
  
  const levelMatch = $(descriptionHtml).text().match(/killed at level (\d+)/i);
  const victimLevel = levelMatch ? parseInt(levelMatch[1], 10) : null;

  const reasonMatch = $(descriptionHtml).text().match(/\(([^)]+)\)/);
  const reason = reasonMatch ? reasonMatch[1].trim() : '';
  const isTeammateKill = reason.toLowerCase().includes('unjustified');

  return { victim, killer, victimLevel, killerLevel: victimLevel, reason, isTeammateKill };
};

// Extract killer from text if not found in anchors
const extractKillerFromText = (text) => {
  const parts = text.split(' killed at level ');
  if (parts.length > 1) {
    const killerPart = parts[1].split(' by ')[1];
    return killerPart ? killerPart.trim().split(' (')[0] : '';
  }
  return '';
};

module.exports = scrapeDeathRecorder;