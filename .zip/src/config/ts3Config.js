require('dotenv').config();

module.exports = {
  connection: {
    defaultServerPort: 9987,
    queryPort: process.env.TS3_QUERY_PORT || 10011,
    reconnectDelay: 2000,
    cleanupDelay: 500
  },
  channel: {
    codec: 4,
    codecQuality: 10,
    maxClients: -1,
    statusChannel: {
      name: "━━ Bert the Bot [Online] ━━",
      description: "[center][b]Bot Status[/b]\n[color=green]✓ Connected[/color]\n\nType !help for commands[/center]",
      topic: "Bot Status: Online"
    }
  },
  notifications: {
    enabled: true,
    retryAttempts: 3,
    retryDelay: 1000
  },
  commands: {
    prefix: '!',
    available: ['ping', 'help', 'status']
  }
};