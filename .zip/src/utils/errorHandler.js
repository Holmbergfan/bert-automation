const logger = require('./logger');

class BotError extends Error {
  constructor(message, statusCode = 500) {
    super(message);
    this.statusCode = statusCode;
    this.name = 'BotError';
  }
}

const asyncHandler = fn => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(error => {
    logger.error('Request error:', { message: error.message, stack: error.stack });
    res.status(error.statusCode || 500).json({ error: error.message });
  });

const errorMiddleware = (err, req, res, next) => {
  logger.error('Error:', {
    message: err.message,
    stack: err.stack,
    path: req.path
  });
  res.status(err.statusCode || 500).json({ error: err.message });
};

module.exports = { BotError, asyncHandler, errorMiddleware };