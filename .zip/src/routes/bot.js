// src/routes/bot.js

const express = require('express');
const router = express.Router();
const botController = require('../controllers/botController');
const { asyncHandler } = require('../utils/errorHandler');

// Route definitions
router.get('/status', asyncHandler(botController.getStatus));
router.post('/command', asyncHandler(botController.sendCommand));
router.post('/settings', asyncHandler(botController.updateSettings));

module.exports = router;
