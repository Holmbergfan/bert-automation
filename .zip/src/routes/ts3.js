// src/routes/ts3.js

const express = require('express');
const router = express.Router();
const botController = require('../controllers/botController');
const { asyncHandler } = require('../utils/errorHandler');

router.post('/assign-admin', asyncHandler(botController.assignServerAdmin));

module.exports = router;
