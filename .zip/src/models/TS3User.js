const mongoose = require('mongoose');

const ts3UserSchema = new mongoose.Schema({
  clientId: { type: String, required: true, unique: true },
  nickname: String,
  lastSeen: { type: Date, default: Date.now },
  status: {
    type: String,
    enum: ['online', 'offline', 'away'],
    default: 'offline'
  },
  channelId: Number
}, { timestamps: true });

module.exports = mongoose.model('TS3User', ts3UserSchema);
