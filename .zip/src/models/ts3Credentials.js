// src/models/ts3Credentials.js

const mongoose = require('mongoose');

const ts3CredentialsSchema = new mongoose.Schema({
  _id: String,
  host: { type: String, required: true },
  port: { type: Number, required: true, default: 10011 },
  username: { type: String, required: true },
  password: { type: String, required: true },
  nickname: { type: String, required: true },
  serverId: { type: Number, required: true },
  channelId: { type: Number, required: true }
}, { collection: 'ts3_credentials' });

module.exports = mongoose.model('TS3Credentials', ts3CredentialsSchema);